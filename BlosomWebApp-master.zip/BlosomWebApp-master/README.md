# BlosomWebApp
### 1. Initially, run simulations on BLOSOM and locate the folder from data/Saves of the BLOSOM package 
### 2. Copy this simulation folder that contains the shapefiles and inputs.txt to the location where the Integrator.py file is located.
### 3. Make sure all the packages are correctly installed
### 4. Run Integrator.py
### 5. It automatically generates the required folders
### 6. Corresponding files are automatically generated into the folders
### 7. Search for the SDSS files folder and copy its contents to the data folder of the web app 
### 8. Now, make sure ESI layer folder is present
### 9. Start the server and the SDSS is up and ready to go!!

